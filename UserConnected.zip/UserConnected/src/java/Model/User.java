/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

/**
 *
 * @author A8Q2NZZ
 */
@WebListener
public class User implements HttpSessionBindingListener {

    // All logins.
    public static Map<User, HttpSession> logins = new ConcurrentHashMap<>();

    public static String[] getConnectedUsers(){
    String [] users=new String[logins.size()];
    int i=0;
        for (Map.Entry<User, HttpSession> entry : logins.entrySet()) {
            User key = entry.getKey();
            HttpSession value = entry.getValue();
            users[i++]=key.username;
        }
    return users;
    }
    
    // Normal properties.
    private Long id;

    public Long getId() {
        return id;
    }

    public User(String username) {
        this.username = username;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    private String username;
    // Etc.. Of course with public getters+setters.
    
    
    @Override
    public boolean equals(Object other) {
        return (other instanceof User) && (id != null) ? id.equals(((User) other).id) : (other == this);
    }

    @Override
    public int hashCode() {
        return (id != null) ? (this.getClass().hashCode() + id.hashCode()) : super.hashCode();
    }

    @Override
    public void valueBound(HttpSessionBindingEvent event) {
        HttpSession session = logins.remove(this);
        if (session != null) {
            session.invalidate();
        }
        logins.put(this, event.getSession());
    }

    @Override
    public void valueUnbound(HttpSessionBindingEvent event) {
        logins.remove(this);
    }

}
